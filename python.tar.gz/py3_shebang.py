#!/usr/bin/env python3
print("ello!")
print("Did you say, hello?")
print("No, I said ello, but that\'s close enough.")

# mycode
Tracking my code
Wanting to learn how to version control projects with git.
# mycode (Project Title)

One Paragraph of your project description goes here. Describe what you're trying to do.
What is the purpose of putting up this repo?

## Getting Started

These instructions will get you a copy of the project up and running on your local machine
for development and testing purposes. See deployment for notes on how to deploy the project
on a live system.

### Prerequisites

What things are needed to install the software and how to install them. For now, maybe copy in
"how to install python and python3 using apt."

## Built With

* [Python](https://www.python.org/) - The coding language used

## Authors

* **Your Name** - *Initial work* - [YourWebsite](https://example.com/)
